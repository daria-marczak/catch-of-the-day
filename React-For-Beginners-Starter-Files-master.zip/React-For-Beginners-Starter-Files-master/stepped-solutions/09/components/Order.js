import React from "react";

class Order extends React.Component {
  render() {
    return <div className="order">Order!!!</div>;
  }
}

export default Order;
