import React from "react";

class Inventory extends React.Component {
  render() {
    return <div className="inventory">Inventory!!!</div>;
  }
}

export default Inventory;
